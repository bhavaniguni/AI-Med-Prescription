
import gradio as gr
from transformers import pipeline

# Load model (example: medical text classification / NER)
nlp = pipeline("ner", model="dslim/bert-base-NER", grouped_entities=True)

def verify_prescription(prescription_text):
    try:
        results = nlp(prescription_text)
        return {"Entities": results}
    except Exception as e:
        return {"Error": str(e)}

# Gradio UI
iface = gr.Interface(
    fn=verify_prescription,
    inputs=gr.Textbox(lines=5, placeholder="Enter prescription details here..."),
    outputs="json",
    title="AI Medical Prescription Verifier",
    description="This app extracts medical entities (drug names, dosages, etc.) from prescription text to help in verification."
)

if __name__ == "__main__":
    iface.launch()
