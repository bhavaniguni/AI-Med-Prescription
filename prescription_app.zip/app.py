import gradio as gr
from transformers import pipeline

# Load NLP pipeline for named entity recognition
ner_pipeline = pipeline("ner", grouped_entities=True)

def analyze_prescription(text):
    try:
        entities = ner_pipeline(text)
        response = "Detected medical terms:\n"
        for ent in entities:
            response += f"- {ent['word']} ({ent['entity_group']}, score={ent['score']:.2f})\n"
        return response
    except Exception as e:
        return f"Error: {str(e)}"

# Gradio Interface
iface = gr.Interface(
    fn=analyze_prescription,
    inputs=gr.Textbox(lines=4, placeholder="Paste prescription here..."),
    outputs="text",
    title="AI Medical Prescription Verifier",
    description="Analyzes prescriptions, detects medical terms, and provides insights."
)

if __name__ == "__main__":
    iface.launch()
