# AI Medical Prescription Verifier

This Hugging Face Space analyzes prescriptions using NLP.  
It detects **medical terms, drug names, and entities** from text.

### How to use:
1. Paste prescription text into the box.
2. Click submit.
3. Get detected medical entities and insights.

---
Powered by **Transformers + Gradio**.
