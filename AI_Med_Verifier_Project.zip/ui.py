import streamlit as st
import requests
import os

st.set_page_config(page_title="AI Prescription Verifier", layout="centered")
st.title("AI Medical Prescription Verifier — Prototype")

st.markdown("Paste prescription text below and provide patient age (optional). This demo uses public APIs and mock interactions.")

text = st.text_area("Prescription text", height=150)
age = st.number_input("Patient age (optional)", min_value=0, max_value=120, value=30)

if st.button("Analyze"):
    if not text.strip():
        st.error("Please paste prescription text.")
    else:
        try:
            api_url = st.text_input("API URL (leave default if running locally)", value="http://127.0.0.1:8000/analyze")
            payload = {"text": text, "age": age}
            with st.spinner("Analyzing..."):
                resp = requests.post(api_url, json=payload, timeout=20)
                resp.raise_for_status()
                data = resp.json()
            st.success("Analysis complete")
            st.subheader("Extracted Entities")
            st.json(data.get("extracted", {}))
            st.subheader("Normalized (RxCUI)")
            st.json(data.get("normalized", {}))
            st.subheader("Flagged Interactions")
            st.json(data.get("interactions", []))
            st.subheader("Dosage Recommendations (fetched from openFDA if available)")
            st.json(data.get("dosage_recommendations", {}))
            st.subheader("Alternative Suggestions")
            st.json(data.get("alternatives", {}))
        except Exception as e:
            st.error(f"Error calling backend: {e}")
