from transformers import pipeline

# Demo NER pipeline using a public BioBERT model (no fine-tuning).
# For production: fine-tune on annotated prescription data.
try:
    ner = pipeline("ner", model="dmis-lab/biobert-v1.1", aggregation_strategy="simple")
except Exception as e:
    # fallback to a smaller model if loading fails in constrained environments
    ner = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")

def extract_entities(text: str):
    """
    Returns a dict with lists: drugs and dosages (simple heuristic)
    """
    results = ner(text)
    drugs, dosages = [], []
    for r in results:
        label = r.get("entity_group", "") or r.get("entity", "")
        word = r.get("word", "")
        # basic heuristics: many NER models mark chemical/drug as MISC/ORG/PER/DRUG - we treat tokens heuristically
        # In practice, fine-tune model so entity_group contains DRUG/DOSE etc.
        lw = word.lower()
        if any(k in lw for k in ["mg", "mcg", "tablet", "capsule", "tab", "inj", "ml"]):
            dosages.append(word)
        else:
            drugs.append(word)
    return {"drugs": list(dict.fromkeys([d.strip() for d in drugs if d.strip()])),
            "dosages": list(dict.fromkeys([d.strip() for d in dosages if d.strip()]))}
