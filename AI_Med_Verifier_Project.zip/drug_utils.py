import requests

def get_rxcui(drug_name: str):
    """
    Query RxNav / RxNorm for RxCUI by name.
    """
    try:
        url = f"https://rxnav.nlm.nih.gov/REST/rxcui.json?name={requests.utils.quote(drug_name)}"
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        data = r.json()
        return data.get("idGroup", {}).get("rxnormId", [None])[0]
    except Exception:
        return None

def check_interactions(drug_list):
    """
    Mock interaction checker. Replace with DrugBank or licensed DDI DB for production.
    """
    risky_pairs = {("warfarin", "aspirin"): "High bleeding risk - increased anticoagulation effect",
                   ("warfarin", "ibuprofen"): "Increased bleeding risk"}
    flagged = []
    lowered = [d.lower() for d in drug_list]
    for i, d1 in enumerate(lowered):
        for j, d2 in enumerate(lowered):
            if i >= j:
                continue
            key = (d1, d2)
            if key in risky_pairs:
                flagged.append({"pair": (drug_list[i], drug_list[j]), "warning": risky_pairs[key]})
            elif (d2, d1) in risky_pairs:
                flagged.append({"pair": (drug_list[i], drug_list[j]), "warning": risky_pairs[(d2, d1)]})
    return flagged

def fetch_dosage(drug_name: str):
    """
    Fetch dosage/administration section from openFDA drug label (if available).
    """
    try:
        q = f'openfda.generic_name:"{drug_name}"'
        url = f'https://api.fda.gov/drug/label.json?search={q}&limit=1'
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        data = r.json()
        results = data.get("results", [])
        if not results:
            return "Dosage info not found"
        # common keys: 'dosage_and_administration', 'indications_and_usage'
        dos = results[0].get("dosage_and_administration")
        if dos:
            if isinstance(dos, list):
                return dos[0]
            return dos
        # fallback to description
        return results[0].get("indications_and_usage", "Dosage info not found")
    except Exception:
        return "Dosage info not available (API error)"

def suggest_alternatives(drug_name: str):
    """
    Very simple alternatives mapping (demo). Replace with class-based lookup for production.
    """
    alternatives = {
        "warfarin": ["dabigatran", "apixaban"],
        "aspirin": ["clopidogrel"],
        "paracetamol": ["ibuprofen"]
    }
    return alternatives.get(drug_name.lower(), [])
