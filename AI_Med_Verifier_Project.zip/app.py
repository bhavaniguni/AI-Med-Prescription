from fastapi import FastAPI
from pydantic import BaseModel
from ner_model import extract_entities
from drug_utils import get_rxcui, check_interactions, fetch_dosage, suggest_alternatives

app = FastAPI(title="AI Medical Prescription Verifier")

class Prescription(BaseModel):
    text: str
    age: int = None

@app.post("/analyze")
def analyze(prescription: Prescription):
    entities = extract_entities(prescription.text)
    drugs = entities.get("drugs", [])

    normalized = {d: get_rxcui(d) for d in drugs}
    interactions = check_interactions(drugs)
    dosage = {d: fetch_dosage(d) for d in drugs}
    alternatives = {d: suggest_alternatives(d) for d in drugs}

    return {
        "extracted": entities,
        "normalized": normalized,
        "interactions": interactions,
        "dosage_recommendations": dosage,
        "alternatives": alternatives
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
